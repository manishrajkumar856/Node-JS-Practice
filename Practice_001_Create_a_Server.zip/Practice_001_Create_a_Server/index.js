//Core Module
const http = require('http');

//Creating our server
const server = http.createServer((req, res)=>{
    console.log(req);
    console.log("Process Start");
    res.write("<h1> Hello World </h1>");
});

const PORT = 3009;

// listening to  the server
server.listen(PORT, ()=>{
    console.log(`Server Running at http://localhost:${PORT}/`);
});

console.log("Hello Worls");